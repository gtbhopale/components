$(document).ready(function(){
   $("#userpassword").keyup(function(){
                                //initial strength
                var password=document.getElementById('userpassword').value;

                                var strength = 0;
                                //if the password length is less than 6, return message.
                                if (password.length < 8) {
                                    $('.passStrength.red').css({
                                        'background-color': '#d95553'
                                    });
                                }
                                //length is ok, lets continue.
                                //if length is 1 or more characters, increase strength value
                                if (password.length > 0) strength += 1
                                    //if password contains both lower and uppercase characters, increase strength value
                                if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) strength += 1
                                    //if it has numbers and characters, increase strength value
                                if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/)) strength += 1
                                    //if it has one special character, increase strength value
                                if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
                                    //if it has two special characters, increase strength value
                                if (password.match(/(.*[!,%,&,@,#,$,^,*,?,_,~].*[!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
                                    //now we have calculated strength value, we can return messages
                                    //if value is less than 2
                                if (strength < 2 && strength != 0)
                                {
                                    $('.passStrength.red').css({
                                        'background-color': '#d95553'
                                    });
                                    $('.passStrength.yelow').css({
                                        'background-color': '#fff'
                                    });
                                    $('.passStrength.green').css({
                                        'background-color': '#fff'
                                    });
                                    $('.passStrength.greenfirst').css({
                                        'background-color': '#fff'
                                    });
                                    //$('.passwordmsg').text(ACC.passwordEasy);
                                }
                                else if (strength ==2)
                                {
                                    $('.passStrength.red').css({
                                        'background-color': '#d95553'
                                    });
                                    $('.passStrength.yelow').css({
                                        'background-color': '#efad58'
                                    });
                                    $('.passStrength.greenfirst').css({
                                        'background-color': '#fff'
                                    });
                                    $('.passStrength.green').css({
                                        'background-color': '#fff'
                                    });
                                    //$('.passwordmsg').text(ACC.passwordMedium);
                                }
                                else if (strength == 3)
                                {
                                    if (password.length > 7)
                                    {
                                        $('.passStrength.red').css({
                                            'background-color': '#d95553'
                                        });
                                        $('.passStrength.yelow').css({
                                            'background-color': '#efad58'
                                        });
                                        $('.passStrength.greenfirst').css({
                                            'background-color': '#007b34'
                                        });
                                        $('.passStrength.green ').css({
                                            'background-color': '#fff'
                                        });
                                        //$('.passwordmsg').text(ACC.passwordStrong);
                                    }
                                }
                                else if (strength > 3)
                                {
                                    if (password.length > 7)

                                    {
                                        
                                        $('.passStrength.red').css({
                                            'background-color': '#007b34'
                                        });
                                        $('.passStrength.yelow').css({
                                            'background-color': '#007b34'
                                        });
                                        $('.passStrength.greenfirst').css({
                                            'background-color': '#007b34'
                                        });
                                        $('.passStrength.green ').css({
                                            'background-color': '#007b34'
                                        });
                                        //$('.passwordmsg').text(ACC.passwordVeryStrong);
                                    }
                                }
                                else
                                {
                                    $('.passStrength').css({
                                        'background-color': '#fff'
                                    });
                                    $('.passwordmsg').text("");
                                }
                
                            });
                 $(document).on("focus", "#userpassword", function(){
                                $("#createuserPasswordHint").show();
                 });
                
                 $(document).on("blur", "#userpassword", function(){
                                 $("#createuserPasswordHint").hide();
                });

});

