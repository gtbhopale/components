$(document).ready(function() {
   
 $('.navbar-toggle').click(function(){
 	//alert(1);
 	$('#slide-out ').css({"width": "240px","transform": "translateX(0px)"});
 	$('#sidenav-overlay').css("opacity","1");
 });
    $('#sidenav-overlay ,#slide-out .nav-header .fa-times').click(function(){
    	$('#sidenav-overlay').css("opacity","0");
    	$('#slide-out').css({"width": "240px","transform": "translateX(-105%)"});
    });

    $('.content').hide();
  	$('.listelement').on('click', function(){
  		
    if(!($(this).next('.content').is(':visible'))){
      $('.content').slideUp();
      $(this).next('.content').slideDown();
     
    } else {
      $('.content').slideUp();
      
    }
  });     
    
});