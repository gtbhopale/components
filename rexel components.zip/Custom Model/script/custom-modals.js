function modalOpen() {
  	var showData = $('.modal-content p');
    $.getJSON('json/custom-modal.json', function (data) {
      showData.empty();
      showData.append(data.modalcontent);
    });
    $('#' + $(this).attr('modal')).fadeIn(300);
    $('.modal-overlay').fadeIn(300);
}
function modalClose() {
    $('.modal:visible').fadeOut(300);
    $('.modal-overlay').fadeOut(300);
}
function modalSuccessCustom() {
    alert('Success! Do some custom function.');
}
$(document).ready(function() {
    $('button[modal^="modal"], button[modal*="modal"]').click(modalOpen);
    $('.modal-close, .modal-secondary, .modal-overlay').click(modalClose);
});