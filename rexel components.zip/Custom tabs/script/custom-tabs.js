$(document).ready(function() {
    var showData1 = $('.tab-content #sectionA p');
     var showData2 = $('.tab-content #sectionB p');
    $.getJSON('json/custom-modal.json', function (data) {
      console.log(data.tabdata1);
     showData1.empty();
     showData1.append(data.tabdata1);
     showData2.empty();
     showData2.append(data.tabdata2);
     
	});
    
});