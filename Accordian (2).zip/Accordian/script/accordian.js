$(document).ready(function() {
	//jQuery.support.cors = true;
jQuery.browser = {};
    (function () {
        jQuery.browser.msie = false;
        jQuery.browser.version = 0;
        if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
            jQuery.browser.msie = true;
            jQuery.browser.version = RegExp.$1;
        }
    })();

	var $facetValue=$(".facetValue");
 	$(".facetHead").on("click",function(){
	var id= $(this).find(".facetToggle").attr('value');
	
	  if($(this).next('.facetValue').hasClass('show')){
	  	$(this).next('.facetValue').removeClass('show');
	  	$(".facetToggle").removeClass('toggleArrow');
	  }
	  else{
	  	$('.facetValue').removeClass('show');
	  	$(".facetToggle").removeClass('toggleArrow');
	  	$(this).find(".facetToggle").toggleClass('toggleArrow');
	  
	  	 var data = getValues(id);
	  	$(this).next('.facetValue').addClass('show');
	  }

	 });

	 


	 function getValues(id){
	   	var dataObj = {};
	   		if ($.browser.msie && window.XDomainRequest) {
		    // Use Microsoft XDR
		    var xdr = new XDomainRequest();
		    xdr.open("get", "json/custom-modal.json");
		    xdr.onload = function () {
		    var JSON = $.parseJSON(xdr.responseText);
		    if (JSON == null || typeof (JSON) == 'undefined')
		    {
		        JSON = $.parseJSON(data.firstChild.textContent);
		    }
		    processData(JSON);
		    };
		    xdr.send();
		} else {
		          $.ajax({
		          type: 'GET',
		          url: "json/custom-modal.json",
		          processData: true,
		          data: {},
		          dataType: "json",
		          success: function (data) {
		          	 $facetValue.empty();	
			          for(var i= 0;i<data.data.length;i++){
						if(data.data[i].id == id){
						
							dataObj =  data.data[i].category;
						}
					}
					var items = [];
					   $.each( dataObj, function( key, val ) {
					     items.push( "<li id='" + key + "'><a href='#'>" + val + "</a></li>" );
					   });
				      $( "#"+id+".facetValue" ).html();
				    
					   $( "<ul/>", {
					      html: items.join( "" )
					   }).appendTo( "#"+id+".facetValue" ); }
		          });
		}

  }

  /*function processData(data){
  			for(var i= 0;i<data.data.length;i++){
						if(data.data[i].id == id){
						
							dataObj =  data.data[i].category;
						}
					}
					var items = [];
					   $.each( dataObj, function( key, val ) {
					     items.push( "<li id='" + key + "'><a href='#'>" + val + "</a></li>" );
					   });
				      $( "#"+id+".facetValue" ).html();
				    
					   $( "<ul/>", {
					      html: items.join( "" )
					   }).appendTo( "#"+id+".facetValue" );

  }*/
	   	/*$.getJSON( "json/custom-modal.json" + "&format=json&callback=?", function(data) {
			 $facetValue.empty();			
			for(var i= 0;i<data.data.length;i++){
				
				if(data.data[i].id == id){
					
					dataObj =  data.data[i].category;
				}
			}

			var items = [];
		   $.each( dataObj, function( key, val ) {
		     items.push( "<li id='" + key + "'><a href='#'>" + val + "</a></li>" );
		   });
	      $( "#"+id+".facetValue" ).html();
	    
		   $( "<ul/>", {
		      html: items.join( "" )
		   }).appendTo( "#"+id+".facetValue" );
		   
		  
		});*/

		/*$.ajax({
			  url: "json/custom-modal.json",
			  cache: false,
			  dataType: "json",
			  success: function(data) {
				    for(var i= 0;i<data.data.length;i++){
						if(data.data[i].id == id){
						
							dataObj =  data.data[i].category;
						}
					}
					var items = [];
					   $.each( dataObj, function( key, val ) {
					     items.push( "<li id='" + key + "'><a href='#'>" + val + "</a></li>" );
					   });
				      $( "#"+id+".facetValue" ).html();
				    
					   $( "<ul/>", {
					      html: items.join( "" )
					   }).appendTo( "#"+id+".facetValue" );
			  },
			  error: function (request, status, error) { alert(status + ", " + error); }
			})*/

	   

});