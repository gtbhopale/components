$(document).ready(function () {
	var catinstall=$(".catinstall div ");
	var catdist=$(".catdist div");
	var catul=$(".catdd ul");

    $(".navBarBrwsProds").mouseover(function(){
        $("#browse-products-panelId").css("display", "block");
    });
    $(".navBarBrwsProds").mouseout(function(){
        $("#browse-products-panelId").css("display", "none");
    });

    $.getJSON('json/custom-modal.json', function (data) {
    	 var items = [];
		 var items1=[];
		 $.each( data.installation, function( key, value ) {
		    items.push( "<li id='" + key.key + "'><a>" + value.value + "</a></li>" );
		  });
		 
		  $( "<ul/>", {
		       html: items.join( "" )
		  }).appendTo( ".catinstall" );
 	
 		$.each( data.distributor, function( key, value ) {
		    items1.push( "<li id='" + key + "'><a>" + value.value + "</a></li>" );
		  });
		 
		  $( "<ul/>", {
		       html: items1.join( "" )
		  }).appendTo( ".catdist" );
     
    });

   $(".browse-brands li a ").on("click",function(){
	   	var labelName=$(this).text();

	   	$(".submenu-lable").text($(this).text());
	   	console.log($(this).text());
	   	$('.browse-brands li.active').removeClass('active');
		$(this).parent().addClass('active');

		var id= $(this).attr('value');
			var data = getValues(id);
		});

		function getValues(id){
		   	var dataObj = {};
		   	$.getJSON( "json/custom-modal.json", function(data) {
				catul.empty();	
					
				for(var i= 0;i<data.data.length;i++){
					
					if(data.data[i].id == id){
						
						dataObj =  data.data[i].category;
					}
				}
				var itemsList = [];
			    $.each( dataObj, function( key, val ) {
			   
			     catul.append("<li id='" + key + "'><a href='#'>" + val + "</a></li>" );
			   });
 
			});
		}
});

