$(document).ready(function() {
	var $facetValue=$(".facetValue");
 	$(".facetHead").on("click",function(){
	var id= $(this).find(".facetToggle").attr('value');
	
	  if($(this).next('.facetValue').hasClass('show')){
	  	$(this).next('.facetValue').removeClass('show');
	  	$(".facetToggle").removeClass('toggleArrow');
	  }
	  else{
	  	$('.facetValue').removeClass('show');
	  	$(".facetToggle").removeClass('toggleArrow');
	  	$(this).find(".facetToggle").toggleClass('toggleArrow');
	  
	  	 var data = getValues(id);
	  	$(this).next('.facetValue').addClass('show');
	  }

	 });
	 function getValues(id){
	   	var dataObj = {};
	   	$.getJSON( "json/custom-modal.json", function(data) {
			 $facetValue.empty();			
			for(var i= 0;i<data.data.length;i++){
				
				if(data.data[i].id == id){
					
					dataObj =  data.data[i].category;
				}
			}

			var items = [];
		   $.each( dataObj, function( key, val ) {
		     items.push( "<li id='" + key + "'><a href='#'>" + val + "</a></li>" );
		   });
	      $( "#"+id+".facetValue" ).html();
	    
		   $( "<ul/>", {
		      html: items.join( "" )
		   }).appendTo( "#"+id+".facetValue" );
		   
		});

	   }
});