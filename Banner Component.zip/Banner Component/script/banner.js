$(document).ready(function() {
  $.getJSON('json/custom-json.json', function (data) {
			console.log(data);
			var imgList= "";

            $.each(data.items, function () {
                imgList +="<li><img src="+this.url+" id=\"image\"/></li>";

            });
             $('.slides').append(imgList);
             $('.flexslider').flexslider({
			    animation: "slide"
			  });
        });

});