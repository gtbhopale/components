$(document).ready(function(){

	$.getJSON('json/custom-modal.json', function (data) {
			console.log(data);
			var imgList= "";

            $.each(data.items, function () {
                imgList +="<li><img src="+this.url+" id=\"image\"/><p><a href='#'>"+this.caption+"</a></p></li>";

            });
            
            $('#slider1 .overview').append(imgList);
            $('#slider5 .overview').append(imgList);

            $('#slider1').tinycarousel({
			 	axis:"x",
			 	display: 3,
			 	controls: true,
			 	pager: true,
			 });
             $('#slider5').tinycarousel({
			 	axis:"y",
			 	display: 3,
			  });

    });

});


