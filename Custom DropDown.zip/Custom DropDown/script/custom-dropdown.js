$(document).ready(function(){

$.getJSON( "json/custom-modal.json", function( data ) {
	console.log(data);
	  var items = [];
	  $.each( data, function( key, val ) {
	    items.push( "<li><a id='" + key + "'>" + val + "</a></li>" );
	  });
	 
	  $( "<ul/>", {
	    "class": "dropdown-menu",
	    html: items.join( "" )
	  }).appendTo(".dropDownContent");

	  $(".dropdown-menu li").on("click",function() {
		
	    $('.dropdown-menu').removeClass("showDropdown");
	    $(".btn i").removeClass("rotated");

	});
});

	$(".dropdown .btn").on("click",function(){
		$('.dropdown-menu').toggleClass("showDropdown");

		if($(".dropdown-menu").hasClass("showDropdown")){
			$(".btn i").addClass("rotated");
			}
		else{
			$(".btn i").removeClass("rotated");
		}
	});

	$(document).bind('click', function(e) {
	    var $clicked = $(e.target);
	    if (! $clicked.parents().hasClass("dropdown"))
	         $('.dropdown-menu').removeClass("showDropdown");
	     	if($(".dropdown-menu").hasClass("showDropdown")){
				$(".btn i").addClass("rotated");
				}
			else{
				$(".btn i").removeClass("rotated");
			}
	});



});


